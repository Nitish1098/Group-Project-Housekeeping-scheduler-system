package com.example.demo.services;

import java.util.List;

import com.example.demo.entities.AdminRegistration;


public interface AdminRegistrationService {
	
	
	AdminRegistration saveAdminRegistration(AdminRegistration adminRegistration);

	List<AdminRegistration> getAllAdmin();

	AdminRegistration getAdminRegistrationById(long id);

}
