package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.UpdateProfile;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repositories.UpdateProfileRepository;

@Service
public class UpdateProfileService {
	
	
	@Autowired
	private UpdateProfileRepository updateProfileRepository;
	
	
	public UpdateProfile updateProfile(UpdateProfile updateProfile, long id) {

		UpdateProfile updateProfileDetails = updateProfileRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Profile", "Id", id));

		updateProfileDetails.setName(updateProfile.getName());
		updateProfileDetails.setRollnumber(updateProfile.getRollnumber());
		updateProfileDetails.setPassword(updateProfile.getPassword());
		updateProfileDetails.setFloor(updateProfile.getFloor());
		updateProfileDetails.setRoomNo(updateProfile.getRoomNo());
	
		updateProfileRepository.save(updateProfileDetails);
		return updateProfileDetails;
	}

	
}
