
package com.example.demo.services;

import java.util.List;


import com.example.demo.entities.AdminRequestsSchedule;

public interface AdminRequestScheduleService {

	AdminRequestsSchedule saveAdminRequestSchedule(AdminRequestsSchedule adminRequestsSchedule);

	List<AdminRequestsSchedule> getAllRequests();

	AdminRequestsSchedule getRequestById(long empid);

	AdminRequestsSchedule updateRequestSchedule(AdminRequestsSchedule adminRequestsSchedule, long empid);

	void deleteRequest(long empid);

}
