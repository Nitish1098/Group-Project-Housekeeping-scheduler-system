package com.example.demo.services;



import com.example.demo.entities.AdminLogin;


public interface AdminLoginService {
	

	AdminLogin saveAdmin(AdminLogin adminLogin);
    Boolean verifyAdmin(String name, String password);

}
