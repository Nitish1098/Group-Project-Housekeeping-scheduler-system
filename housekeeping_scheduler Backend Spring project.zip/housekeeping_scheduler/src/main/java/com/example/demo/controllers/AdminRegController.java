package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.AdminLogin;
import com.example.demo.entities.AdminRegistration;
import com.example.demo.services.AdminLoginService;
import com.example.demo.services.AdminRegistrationService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class AdminRegController {
	
	@Autowired
	private AdminRegistrationService adminRegistrationService;
	
	@Autowired
	private AdminLoginService adminLoginService;

	public AdminRegController() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@PostMapping("/addAdmin_registration")
	public ResponseEntity<AdminRegistration> saveAdminRegistration(@RequestBody AdminRegistration adminRegistration) {
		String name=adminRegistration.getName();
		String password=adminRegistration.getPassword();
		AdminLogin n = new AdminLogin();
	        n.setName(name);
	        n.setPassword(password);
	        adminLoginService.saveAdmin(n);
		return new ResponseEntity<AdminRegistration>(
				adminRegistrationService.saveAdminRegistration(adminRegistration), HttpStatus.CREATED);
	}

	@GetMapping("/viewAdmin")
	public List<AdminRegistration> getAllAdmin() {
		return adminRegistrationService.getAllAdmin();
	}

	@GetMapping("/getAdmin/{id}")
	public ResponseEntity<AdminRegistration> getAdminById(@PathVariable("id") long adminId) {
		return new ResponseEntity<AdminRegistration>(
				adminRegistrationService.getAdminRegistrationById(adminId), HttpStatus.OK);
	}

}
