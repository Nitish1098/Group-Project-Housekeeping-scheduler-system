import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { adminregister } from './adminregister';

@Injectable({
  providedIn: 'root'
})
export class AdminregisterService {

  constructor(private http: HttpClient) { }
  url: string = "http://localhost:8080/api/addAdmin_registration"

  addadmin(admin: adminregister) {
    return this.http.post(this.url, admin)
  }
}
