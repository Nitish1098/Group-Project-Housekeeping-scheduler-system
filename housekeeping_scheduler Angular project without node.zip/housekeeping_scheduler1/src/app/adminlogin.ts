export class adminlogin {
    name: string
    password: string
}