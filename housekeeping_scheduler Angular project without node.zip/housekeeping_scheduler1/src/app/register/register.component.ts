import { Component, OnInit } from '@angular/core';
import { adminregister } from '../adminregister';
import { AdminregisterService } from '../adminregister.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private adminregisterservice: AdminregisterService) { }

  admin: adminregister = new adminregister()

  ngOnInit() {

  }

  addadmin() {
    console.log(this.admin)
    this.adminregisterservice.addadmin(this.admin).subscribe(
      (data) => {

        console.log(data);

      });
  }

}
