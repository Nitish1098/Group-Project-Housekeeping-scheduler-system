export class adminregister {
    id: number
    password: string
    name: string
    hostel: string
}