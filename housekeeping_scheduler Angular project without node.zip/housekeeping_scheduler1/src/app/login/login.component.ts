import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { adminlogin } from '../adminlogin';
import { AdminloginService } from '../adminlogin.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],

})
export class LoginComponent implements OnInit {

  constructor(private router: Router, private adminloginservice: AdminloginService

  ) { }

  admin: adminlogin = new adminlogin()

  ngOnInit() {

  }
  login() {
    console.log(this.admin)
    this.adminloginservice.verifyadmin(this.admin).subscribe((res: string) => {
      console.log(res)
      if (res == "true") {

        this.router.navigate(['/dashboard']);
      }
      //else{
      //this.message = "Error"
      //}

    })
  }


}
