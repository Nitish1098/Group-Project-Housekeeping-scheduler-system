import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { adminlogin } from './adminlogin';

@Injectable({
  providedIn: 'root'
})
export class AdminloginService {
  url: string = "http://localhost:8080/api/"
  constructor(private http: HttpClient) { }

  verifyadmin(admin: adminlogin) {
    return this.http.post(this.url, admin, { responseType: 'text' })
  }
}
